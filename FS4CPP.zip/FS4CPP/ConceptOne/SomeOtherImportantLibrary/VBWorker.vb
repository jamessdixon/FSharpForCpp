Imports System.Threading

Public Class VBWorker
    Sub Run()
        Console.WriteLine("VBWorker.Run Invoked")
        Thread.Sleep(TimeSpan.FromSeconds(3))
    End Sub
End Class
