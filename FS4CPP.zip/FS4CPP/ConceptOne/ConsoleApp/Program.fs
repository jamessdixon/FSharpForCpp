﻿
open System
open SomeImportantLibrary
open SomeOtherImportantLibrary

[<EntryPoint>]
let main argv =
    Console.WriteLine("Starting")
    let csWorker = new CSWorker()
    csWorker.Run()
    let vbWorker = new VBWorker()
    vbWorker.Run()
    Console.WriteLine("Ending")
    0
