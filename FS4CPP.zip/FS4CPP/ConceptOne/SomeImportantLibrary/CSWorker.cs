﻿using System;
using System.Threading;

namespace SomeImportantLibrary
{
    public class CSWorker
    {
        public void Run()
        {
            Console.WriteLine("CSWorker.Run Invoked");
            Thread.Sleep(TimeSpan.FromSeconds(3));
        }
    }
}
